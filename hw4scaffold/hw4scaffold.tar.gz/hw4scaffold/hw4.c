/**************************************
 * hw4.c 
 *
 * Ben Mitchell
 * 2015-09-08
 *
 * <Your name here>
 * <Date you last modified this file here>
 *
 * Program for solving word search puzzles.
 *
 *
 * Scaffolding for CS120-F15, HW4 - fill in
 * main, but keep it short; my reference implementation
 * has about 20 lines of actual code in main (not counting
 * comments and whitespace).
 *************************************/

#include <stdio.h>
#include "wordsearch.h"

int main (int argc, char* argv[]) {
  return 0;
}
